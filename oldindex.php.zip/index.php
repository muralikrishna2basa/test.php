<html>
   <head>
      <title>Online PHP-7 Script Execution</title>      
   </head>
   
   <body>
      
      <?php
         echo "<h1>Hello, PHP-7!</h1>";
      ?>
   
   </body>
</html>
